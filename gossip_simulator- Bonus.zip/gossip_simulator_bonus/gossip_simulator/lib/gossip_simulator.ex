defmodule GossipSimulator.MainApp do
  use Application

  @moduledoc """
  Documentation for GossipSimulator.MainApp
  """

  @doc """
   Gossip Simulator
  """

  def start(_type, _args) do
    args = System.argv()
    {node_count, topology_type, algorithm_type, kill_nodes_no} = process_args(args)

    GossipSimulator.Supervisor.start_link(
      node_count,
      topology_type,
      algorithm_type,
      kill_nodes_no
    )

    # Saurabh start
    convergence_task = Task.async(fn -> converging(0, 0.9 * node_count) end)
    :global.register_name(:mainproc, convergence_task.pid)
    :global.register_name(:failurehelper, self())
    start_time = System.system_time(:millisecond)
    #
    initiate_gossip(algorithm_type, node_count)
    # kill some nodes
    if kill_nodes_no > 0 do
      killsomerandom(node_count, kill_nodes_no)
    end

    # Saurabh start
    fail_helper(0, 0.9 * node_count)
    Task.await(convergence_task, :infinity)
    time_diff = System.system_time(:millisecond) - start_time
    IO.puts("Time taken to achieve convergence: #{time_diff} milliseconds")
    System.halt(0)
    #
    {:ok, self()}
  end

  def killsomerandom(node_count, kill_nodes_no) do
    list = 1..node_count

    Enum.each(1..kill_nodes_no, fn _x ->
      random_number = Enum.random(list)
      random_worker_name = "worker_node_" <> to_string(random_number)
      IO.puts("Killed Node: #{random_number}")

      if GenServer.whereis(String.to_atom(random_worker_name)) != nil do
        Process.exit(GenServer.whereis(String.to_atom(random_worker_name)), :kill)
      end
    end)
  end

  def converging(nodes_converged, stopping_threshold) do
    # Receive convergence messages for both algorithms
    if(nodes_converged < stopping_threshold) do
      receive do
        {:converged, _pid} ->
          # IO.puts("#{inspect(pid)} Converged #{numNodes}")
          converging(nodes_converged + 1, stopping_threshold)
          # after
          #   5000 ->
          #     IO.puts("Convergence could not be reached for #{nodes_converged}")
          #     # mock process shutdown
          #     send(
          #       :global.whereis_name(:failurehelper),
          #       {:DOWN, :random, :process, :random, :cantconverge}
          #     )
          #
          #     converging(nodes_converged + 1, stopping_threshold)
      end
    else
      IO.puts("#{nodes_converged} nodes converged ")
    end
  end

  def fail_helper(numNodes, stopping_threshold) do
    if(numNodes > stopping_threshold) do
      receive do
        {:DOWN, _, :process, pid, :killed} ->
          IO.puts("#{inspect(pid)} killed")
          fail_helper(numNodes, stopping_threshold)

        {:DOWN, _, :process, _pid, _reason} ->
          fail_helper(numNodes + 1, stopping_threshold)
      end
    else
      nil
    end
  end

  def initiate_gossip(algorithm_type, node_count) do
    cond do
      algorithm_type == "gossip" ->
        GossipSimulator.GossipNode.spread_rumor(1..node_count)

      algorithm_type == "push-sum" ->
        GenServer.cast(:worker_node_1, {:spread_rumor, [0, 0]})
    end
  end

  defp process_args(args) do
    node_count = String.to_integer(Enum.at(args, 0))
    topology_type = Enum.at(args, 1)
    algorithm_type = Enum.at(args, 2)
    killnode = String.to_integer(Enum.at(args, 3))

    IO.inspect(
      "nodes : #{node_count}, topology : #{topology_type}, algorithm : #{algorithm_type},no of nodes to kill : #{
        killnode
      }"
    )

    {node_count, topology_type, algorithm_type, killnode}
  end
end
