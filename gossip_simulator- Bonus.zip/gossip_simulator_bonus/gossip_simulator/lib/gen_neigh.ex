defmodule GossipSimulator.GenNeigh do
  use GenServer

  @name Neigh

  @moduledoc """
  #Gossip Simulator Node
  """

  def start_link(neigh) do
    GenServer.start_link(__MODULE__, [neigh, 0], name: @name)
  end

  def init([neigh, c]) do
    {:ok, [neigh, c]}
  end

  def getneigh() do
    GenServer.call(@name, :get)
  end

  def getCounter() do
    GenServer.call(@name, :getc)
  end

  def removeNeigh(ndex) do
    GenServer.cast(@name, {:remove, ndex})
  end

  def updateCounter(c) do
    GenServer.cast(@name, {:updatec, c})
  end

  def handle_cast({:remove, ndex}, [neighbours, c]) do
    new1 = List.delete(neighbours, ndex)
    {:noreply, [new1, c]}
  end

  def handle_call(:get, _from, [neighbours, c]) do
    {:reply, neighbours, [neighbours, c]}
  end

  def handle_cast({:updatec, cn}, [neighbours, c]) do
    {:noreply, [neighbours, cn]}
  end

  def handle_call(:getc, _from, [neighbours, c]) do
    {:reply, c, [neighbours, c]}
  end
end
