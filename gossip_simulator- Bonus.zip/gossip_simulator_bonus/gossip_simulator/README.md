#Project 2 - Gossip and Push-Sum#

To run Please Give the following input: 
>mix run --no-halt gossip_simulator.exs no_of_nodes topology algorithm no_of_nodes_to_kill
No_of_nodes -> Integer
Topology -> line, full, rand2D, honeycomb, randhoneycomb, 3Dtorus
Algorithm -> push-sum, gossip

